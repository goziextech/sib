var myApp = angular.module('myApp', ['ngRoute']);  //Extension of myApp

myApp.config(function($routeProvider,$locationProvider,$httpProvider){

/*if (!$httpProvider.defaults.headers.get) {
        $httpProvider.defaults.headers.get = {};    
 }    
    
//Disable IE ajax request caching
$httpProvider.defaults.headers.get['If-Modified-Since'] = 'Mon, 26 Jul 1997 05:00:00 GMT';
$httpProvider.defaults.headers.get['Cache-Control'] = 'no-cache';
$httpProvider.defaults.headers.get['Pragma'] = 'no-cache';
    */
//$locationProvider.html5Mode(true);     
//Remove exclamation mark on url
$locationProvider.hashPrefix('');
//$locationProvider.hash('');    
    
//Login    
$routeProvider.when('/', {
 controller:'studentsController',
 cache:false,    
 templateUrl:'views/login.html'    
}) 

//University Dashboard
.when('/university/account/:id', {
 controller:'studentsController',
 cache:false,    
 templateUrl:'views/dashboard.html'       
})

//University Profile
.when('/university-profile/:id', {
 controller:'studentsController',
 cache:false,    
 templateUrl:'views/university-profile.html'       
})

//Manage Applicants
.when('/manage-applicants/:id', {
 controller:'studentsController',
 templateUrl:'views/manage-applicants.html'      
})

//Processed Applicants
.when('/applicants/:id', {
 controller:'studentsController',
 cache:false,    
 templateUrl:'views/applicants.html'       
})

//Travel and Visa
.when('/travel-visa/:id', {
 controller:'studentsController',
 cache:false,    
 templateUrl:'views/travel-visa.html'       
})

// Student Profile
.when('/student-profile/:id', {
 controller:'studentsController',
 cache:false,    
 templateUrl:'views/student-profile.html'       
})

// Student Profile
.when('/student-profile/recruited/:id', {
 controller:'studentsController',
 cache:false,    
 templateUrl:'views/recruited-student-profile.html'       
})

// Student Profile
.when('/student-profile/:id/:id', {
 controller:'studentsController',
 cache:false,    
 templateUrl:'views/student-profile.html'       
})

// Map 
.when('/recruitment-map/:id', {
 controller:'studentsController',
 cache:false,    
 templateUrl:'views/recruitment-map.html'       
})

// Login error
.when('/login/error', {
 controller:'studentsController',
 cache:false,    
 templateUrl:'views/loginerror.html'       
})

// register
.when('/register', {
 controller:'studentsController',
 cache:false,    
 templateUrl:'views/register.html'       
})
//Verify
.when('/verify/:email', {
 controller:'studentsController',
 cache:false,    
 templateUrl:'views/verify.html'       
})
//Verified Redirect
.when('/verified', {
 controller:'studentsController',
 cache:false,    
 templateUrl:'views/verified.html'       
})

//Activate Account
.when('/activate/:email', {
 controller:'studentsController',
 cache:false,    
 templateUrl:'views/activate.html'       
})
//Activate Redirect
.when('/activated', {
 controller:'studentsController',
 cache:false,    
 templateUrl:'views/activated.html'       
})
//Unsubscribe Account
.when('/email/unsubscribe/:email/:id', {
 controller:'studentsController',
 cache:false,    
 templateUrl:'views/unsubscribe.html'       
})
//Unsubscribe Redirect
.when('/email/unsubscribed', {
 controller:'studentsController',
 cache:false,    
 templateUrl:'views/unsubscribed.html'       
})
//Pricing
.when('/pricing/:id', {
 controller:'studentsController',
 cache:false,    
 templateUrl:'views/pricing.html'       
})

//Pricing
.when('/admin/students/:id', {
 controller:'studentsController',
 cache:false,    
 templateUrl:'views/students.html'       
})

//Pricing
.when('/admin/universities/:id', {
 controller:'studentsController',
 cache:false,    
 templateUrl:'views/universities.html'       
})
//Fallback error or 404
.otherwise({
    redirectTo:'/404',
    controller:'studentsController',
    templateUrl:'views/404.html'
});
       
        
});//End Config

